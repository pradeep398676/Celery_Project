from celery import Celery
import os
from celery.schedules import crontab

os.environ.setdefault('DJANGO_SETTINGS_MODULE','djcelery.settings')

app = Celery('djcelery')

app.config_from_object('django.conf:settings',namespace='CELERY')

# Celery Beat Settings
app.conf.beat_schedule = {
    'save_daily': {
        'task' : 'webapp.tasks.my_task',
        'schedule' : crontab(),
        'args': (16, 16),
    },
    'second': {
        'task' : 'webapp.tasks.my_task2',
        'schedule' : crontab(),
    }
}

app.autodiscover_tasks()