from celery import shared_task

@shared_task
def my_task(a, b):
    
    return f'Successfully...{a+b}'


@shared_task
def my_task2():
    
    return 'second method call....'