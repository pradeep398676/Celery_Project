from django.shortcuts import render, HttpResponse
from .tasks import *
from celery.result import AsyncResult
# Create your views here.


def home(request):
    a = my_task.delay(1,2) 
    b = AsyncResult(a).get() # To get actual result of the function
    print(b,type(b))

    return HttpResponse('hiii')